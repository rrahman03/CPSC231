/*
1: 
(a) Raneem Rahman 
(b) 2391103
(c) rrahman@chapman.edu
(d) MP1: Drawing with 2D arrays

2. Drawing.java: the purpose of this assignment is to represent 
a canvas as a 2-dimensional char array that allows a user
to add charachters using a coordinate system

3. no known compile or runtime errors

4. no in code references, I did look at zybooks for some help with understanding
*/
